# Modèle LaTeX

## Département de géomatique appliquée, Université de Sherbrooke

Modèle construit par **Philippe Apparicio**, professeur titulaire, Département de géomatique appliquée, Université de Sherbrooke.

Ce modèle est conçu pour la rédaction d'une thèse de doctorat en télédétection par article de l'Université de Sherbrooke. Il est optimisé pour une compilation sur **Overleaf** (LaTeX) avec le moteur **XeLaTeX** ou **pdfLaTeX**.

------------------------------------------------------------------------

## Structure du projet

```         
Geomatique_these_par_article_latex/
│
├── main.tex                          ← Fichier principal (compiler celui-ci)
├── bibliographie.bib                 ← Base de données bibliographiques (format BibTeX)
│
├── auxiliaires/
│   └── sigles.tex                    ← Définition des abrévations et sigles
│
├── fichiers_introductifs/
│   ├── page_titre.tex                ← Page de titre
│   ├── jury.tex                      ← Page du jury
│   ├── citation.tex                  ← Citation d'ouverture (optionnelle)
│   ├── resume_abstract.tex           ← Résumé et abstract
│   ├── remerciements.tex             ← Remerciements (optionnel)
│   ├── avant_propos.tex              ← Avant-propos (optionnel)
│   ├── declaration_ia.tex            ← Déclaration d'utilisation de l'IA 
│   └── SymbolesEtFormulesChimiques.tex ← Liste des symboles (optionnelle)
│
├── chapitres/
│   ├── partie_I.tex
│   ├── partie_II.tex
│   ├── partie_III.tex
│   ├── 1_introduction.tex
│   ├── 2_cadre_theorique.tex
│   ├── 3_methodologie.tex
│   ├── 4_1er_article.tex
│   ├── 5_12_article.tex
│   ├── 6_discussion.tex
│   ├── 7_conclusion.tex
│   └── annexes.tex
│
├── figures/                          ← Images et figures (PNG, PDF, JPG)
│   ├── figureavecplusieursvignettes.png
│   └── kernels.png
│
├── logoUdes/                         ← Logos officiels de l'UdeS (ne pas modifier)
│   ├── UdeS_logo_h_rgbHR.png
│   ├── UdeS_logo_v_blancHR.png
│   ├── UdeS_logo_v_blanc_uds_noirHR.png
│   ├── UdeS_logo_v_blanc_uds_vertHR.png
│   └── UdeS_logo_v_noirHR.png
│
└── Scripts_Programmes/               ← Scripts de code (R, Python, JavaScript, C, MATLAB)
    ├── CodeR1.R
    ├── CodePython1.py
    ├── GEE1.js
    ├── CodeC1.C
    └── CodeMathlab1.m
```

------------------------------------------------------------------------

## Démarrage rapide sur Overleaf

1.  Téléversez le fichier `.zip` sur [Overleaf](https://www.overleaf.com) via *New Project → Upload Project*.
2.  Overleaf détecte automatiquement `main.tex` comme fichier principal.
3.  Compilez avec **pdfLaTeX** (réglages recommandés : Menu → Settings  → Compiler → pdfLaTeX).

------------------------------------------------------------------------

## Personnalisation de la page de titre

Dans `fichiers_introductifs/page_titre.tex`, deux options de bandeau sont disponibles :

``` latex
\bolBandeaufalse   % Option 2 : bandeau foncé avec logo dans le bandeau (défaut)
\bolBandeautrue    % Option 1 : bandeau UdesFierte avec logo à côté
```

Modifiez également dans ce même fichier : - le **titre** (en français et en anglais si requis); - le **nom de l'auteur.trice**; - la **mention de diplôme** et le **grade**; - la **date** et le **copyright**.

------------------------------------------------------------------------

## Police du texte

Par défaut, la police est **Libertine**. Pour changer, décommentez la ligne correspondante dans `main.tex` (section *Configuration des polices*) et commentez `\usepackage{libertine}` :

``` latex
\usepackage{libertine}   % Libertine (défaut)
%\usepackage{ebgaramond} % EB Garamond
%\usepackage{newpxtext}  % Palatino
%\usepackage{newtxtext}  % Times New Roman
```

La police des formules mathématiques doit être modifiée **en cohérence** avec celle du texte (section immédiatement suivante).

------------------------------------------------------------------------

## Bibliographie

Le fichier `bibliographie.bib` contient les références au format BibTeX. Le style utilisé est **APA** via le package `biblatex` avec le backend `biber`.

La bibliographie s'insère et se formate automatiquement à la fin du document via `main.tex`.

Pour citer dans le texte :

``` latex
\parencite{cle}              % (Auteur, année)
\textcite{cle}               % Auteur (année)
\textcite[p.~12]{cle}        % Auteur (année, p. 12)
```

------------------------------------------------------------------------

## Abrévations et sigles

Définissez vos sigles dans `auxiliaires/sigles.tex` :

``` latex
\newacronym{ndvi}{NDVI}{Normalized Difference Vegetation Index}
```

Utilisez-les dans le texte :

``` latex
\gls{ndvi}    % première utilisation : forme longue (sigle)
\gls{ndvi}    % utilisations suivantes : sigle seulement
\Gls{ndvi}    % majuscule initiale
\glspl{ndvi}  % forme plurielle
```

La liste des abréviations et des sigles est générée automatiquement.

------------------------------------------------------------------------

## Figures

``` latex
\begin{figure}[H]
    \centering
    \includegraphics[width=0.8\textwidth]{figures/nomfigure.png}
    \caption[Légende courte pour la liste des figures]{Légende complète avec description.}
    \label{fig:etiquette}
\end{figure}

% Renvoi dans le texte :
(figure~\ref{fig:etiquette})
```

Placez vos fichiers image dans le dossier `figures/`. Formats acceptés : PNG, PDF, JPG, EPS.

------------------------------------------------------------------------

## Tableaux

``` latex
\begin{table}[H]
    \centering
    \singlespacing
    \begin{threeparttable}
    \caption[Légende courte]{Légende complète.}
    \label{tab:etiquette}
    \begin{tabular}{l c c}
    \hline
    \textbf{Col. A} & \textbf{Col. B} & \textbf{Col. C} \\
    \hline
    Texte & Texte & Texte \\
    \hline
    \end{tabular}
    \begin{tablenotes}[flushleft]
        \small
        \item \textit{Note :} texte facultatif.
    \end{tablenotes}
    \end{threeparttable}
\end{table}
```

------------------------------------------------------------------------

## Équations

``` latex
\begin{equation}
    \text{RMSE} = \sqrt{\frac{\sum_{i=1}^{n}(y_i - \hat{y}_i)^2}{n}}
    \label{eq:etiquette}
\end{equation}

% Renvoi : (équation~\ref{eq:etiquette})
```

------------------------------------------------------------------------

## Scripts et programmes

Les scripts sont inclus via `\lstinputlisting` avec les styles définis dans `main.tex`. Placez vos fichiers dans `Scripts_Programmes/` :

``` latex
% Script R
\begin{lstlisting}[style=styleR, caption={[Légende courte]Légende complète.}, label=code:etiquette]
library(sf)
donnees <- st_read("carte.shp")
\end{lstlisting}

% Ou depuis un fichier externe :
\lstinputlisting[style=stylePython, caption={[Légende courte]Légende complète.}, label=code:py1]
{Scripts_Programmes/CodePython1.py}
```

Styles disponibles : `styleR`, `stylePython`, `styleJavascript`, `styleC`, `styleMATLAB`.

------------------------------------------------------------------------

## Algorithmes

``` latex
\begin{algorithm}[H]
\DontPrintSemicolon
\KwIn{Entrée}
\KwOut{Sortie}
\For{chaque élément}{
    faire quelque chose\;
}
\caption{Nom de l'algorithme}
\label{algo:etiquette}
\end{algorithm}

% Renvoi : (algorithme~\ref{algo:etiquette})
```

------------------------------------------------------------------------

## Pages optionnelles

Dans `main.tex`, commentez les lignes correspondantes pour supprimer les pages non souhaitées :

``` latex
\input{fichiers_introductifs/remerciements}    % optionnel
\input{fichiers_introductifs/avant_propos}     % optionnel
\input{fichiers_introductifs/SymbolesEtFormulesChimiques} % optionnel
```

La page `declaration_ia.tex` est **obligatoire** selon les normes en vigueur.

------------------------------------------------------------------------

## Couleurs de l'Université de Sherbrooke

Les couleurs officielles sont définies dans `main.tex` et disponibles partout dans le document :

| Nom                      | Code hex | Usage typique        |
|--------------------------|----------|----------------------|
| `UdesReussiteContraste1` | #11594B  | Hyperliens, en-têtes |
| `UdesReussiteContraste2` | #18463A  | Titres de chapitres  |
| `UdesReussite`           | #486A5C  | Éléments secondaires |
| `UdesFierteAccessible`   | #018849  | Bandeau (option 1)   |
| `UdesViolet`             | #805286  | Citations            |

Référence complète : [Charte des couleurs UdeS](https://www.usherbrooke.ca/communications/fileadmin/sites/communications/uploads/CharteCouleurs_Contrastes_UdeS.pdf)
